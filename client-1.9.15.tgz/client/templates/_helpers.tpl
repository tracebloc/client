{{- define "imagePullSecret" }}
{{- with .Values.dockerRegistry }}
{{- printf "{\"auths\":{\"%s\":{\"username\":\"%s\",\"password\":\"%s\",\"email\":\"%s\",\"auth\":\"%s\"}}}" .server .username .password .email (printf "%s:%s" .username .password | b64enc) | b64enc }}
{{- end }}
{{- end }}

{{- define "tracebloc.labels" -}}
app.kubernetes.io/name: {{ .Chart.Name }}
app.kubernetes.io/instance: {{ .Release.Name }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
helm.sh/chart: {{ printf "%s-%s" .Chart.Name .Chart.Version }}
{{- end }}

{{- define "tracebloc.selectorLabels" -}}
app.kubernetes.io/name: {{ .Chart.Name }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end }}

{{- define "tracebloc.secretName" -}}
{{ .Release.Name }}-secrets
{{- end }}

{{/*
  tracebloc.sealCheckLabels — the seal-check enumeration contract
  (RFC-0003 §8.2 / backend#1184; consumed by the tracebloc CLI, cli#393).

  Every runnable conformance check in this chart is a `helm.sh/hook: test` Job
  carrying these two labels, so tooling can enumerate the suite without
  hardcoding job names:

    tracebloc.io/seal-check: "true"        — membership marker
    tracebloc.io/seal-check-name: <check>  — stable per-check identifier

  Current check names: egress-enforcement, backend-reachability,
  storage-assertions.

  Enumerate without running anything:   helm get hooks <release>
  While a `helm test` run is live:      kubectl get jobs,pods -n <ns> \
                                          -l tracebloc.io/seal-check=true

  CONTRACT RULES — the label keys and existing check names are public API:
  never rename them; add new checks under new names. Apply this helper to the
  hook Job metadata AND its pod template (pod-level lets the CLI stream logs by
  label). Do NOT apply it to auxiliary hook resources (ServiceAccounts, RBAC) —
  only runnable checks are enumerable. See docs/SEAL-CHECK.md.

  Usage:
    {{- include "tracebloc.sealCheckLabels" (dict "name" "storage-assertions") | nindent 4 }}
*/}}
{{- define "tracebloc.sealCheckLabels" -}}
tracebloc.io/seal-check: "true"
tracebloc.io/seal-check-name: {{ .name | quote }}
{{- end }}

{{- define "tracebloc.serviceAccountName" -}}
{{ .Release.Name }}-jobs-manager
{{- end }}

{{/*
  Name of the shared ServiceAccount the parent chart creates for ingestor
  subchart releases. Single source of truth — used by:
    - templates/ingestor-serviceaccount.yaml (creates the SA)
    - templates/ingestion-authz-configmap.yaml (default authz entry)
  The ingestor subchart's post-install hook runs as this SA; jobs-manager
  validates its token via TokenReview against `ingestionAuthz.allowed`.
  Nil-guarded: pre-#129 stored values from `--reuse-values` upgrades won't
  have `ingestionAuthz.serviceAccountName`, so default to "ingestor".
*/}}
{{- define "tracebloc.ingestorServiceAccountName" -}}
{{- (default dict .Values.ingestionAuthz).serviceAccountName | default "ingestor" -}}
{{- end }}

{{/*
  Release-scoped name for the resource-monitor DaemonSet, ServiceAccount,
  ClusterRoleBinding subject, and selector/pod labels. Multiple releases
  on the same cluster share the tracebloc-node-agents namespace; before
  this naming, two releases collided on the literal `tracebloc-resource-monitor`
  name and Helm refused the second install with "exists, not owned".
  See the v1.2.0 release notes / hasan-prod migration case study.
*/}}
{{- define "tracebloc.resourceMonitorName" -}}
{{ .Release.Name }}-resource-monitor
{{- end }}

{{- define "tracebloc.rbacName" -}}
{{ .Release.Name }}-jobs-manager-rbac
{{- end }}

{{- define "tracebloc.clientDataPvc" -}}
client-pvc
{{- end }}

{{- define "tracebloc.clientDataPvName" -}}
{{ .Release.Name }}-data-pv
{{- end }}

{{- define "tracebloc.clientDataStorage" -}}
{{ .Values.pvc.data | default "50Gi" }}
{{- end }}

{{/*
  hostPath base for the DATASET (shared-images) PV ONLY. Defaults to the
  historical local path /tracebloc so installs without a network dataset mount
  render byte-identically. When the installer bind-mounts a customer network
  (NFS) dir at /tracebloc-data (HOST_DATASET_DIR set), it passes
  hostPath.datasetPath=/tracebloc-data to relocate datasets onto that mount,
  while mysql + logs ALWAYS stay on the local /tracebloc tree (InnoDB over NFS
  is unsafe — backend#743). The /<release>/data suffix is appended here.
  Nil-guarded (default dict) for `--reuse-values` upgrades predating this key.
*/}}
{{- define "tracebloc.clientDataHostPath" -}}
{{ printf "%s/%s/data" ((default dict .Values.hostPath).datasetPath | default "/tracebloc") .Release.Name }}
{{- end -}}

{{- define "tracebloc.clientLogsPvc" -}}
client-logs-pvc
{{- end }}

{{- define "tracebloc.clientLogsPvName" -}}
{{ .Release.Name }}-logs-pv
{{- end }}

{{- define "tracebloc.clientLogsStorage" -}}
{{ .Values.pvc.logs | default "10Gi" }}
{{- end }}

{{- define "tracebloc.mysqlPvc" -}}
mysql-pvc
{{- end }}

{{- define "tracebloc.mysqlPvName" -}}
{{ .Release.Name }}-mysql-pv
{{- end }}

{{- define "tracebloc.mysqlStorage" -}}
{{ .Values.pvc.mysql | default "2Gi" }}
{{- end }}

{{- define "tracebloc.registrySecretName" -}}
{{ .Release.Name }}-regcred
{{- end }}

{{/*
  Release-scoped name shared by the auto-upgrade CronJob, ServiceAccount,
  ClusterRoleBinding, and the ConfigMap holding the upgrade script. Kept
  in one helper so the four resources stay in lockstep — the CRB references
  the SA by name, and the CronJob mounts the ConfigMap by name.
*/}}
{{- define "tracebloc.autoUpgradeName" -}}
{{ .Release.Name }}-auto-upgrade
{{- end }}

{{/*
  Release-scoped name shared by the image-refresh CronJob, ServiceAccount,
  Role, RoleBinding, and ConfigMap. Same lockstep reasoning as
  tracebloc.autoUpgradeName above. Distinct from auto-upgrade because the
  two CronJobs have different cadences, different RBAC scopes (image-refresh
  is namespace-scoped, auto-upgrade is cluster-admin), and customers may
  reasonably disable one but not the other.
*/}}
{{- define "tracebloc.imageRefreshName" -}}
{{ .Release.Name }}-image-refresh
{{- end }}

{{/*
  Whether the image-refresh CronJob has anything to do. When ALL THREE
  managed images (jobs-manager, pods-monitor, ingestor) are
  digest-pinned, the operator has explicitly opted into reproducible
  pinning for every image this CronJob would refresh, so we render
  nothing — no CronJob, no RBAC, no ConfigMap. When at least one is
  unpinned, the CronJob is rendered and the script skips the pinned
  images at runtime via env flags.

  Three pins because #158 added ingestor refresh on top of #154's
  jobs-manager + pods-monitor. Keep this list in sync if more images
  come under auto-refresh in future.

  Nil-guarded with `default dict` on every dereference: these are
  newer top-level keys, and a customer who runs
  `helm upgrade --reuse-values` (instead of the recommended
  --reset-then-reuse-values that autoUpgrade itself uses) could replay
  stored values from before the keys existed. Without the guard,
  `.Values.imageRefresh.enabled` would still nil-coalesce safely, but
  `.Values.images.<image>.digest` could crash if `.Values.images` were
  ever absent. Belt-and-suspenders — see the "nil-guard every new
  top-level value key" rule in CLAUDE.md.
*/}}
{{- define "tracebloc.imageRefreshEnabled" -}}
{{- $ir := default dict .Values.imageRefresh -}}
{{- $imgs := default dict .Values.images -}}
{{- $jm := default dict $imgs.jobsManager -}}
{{- $pm := default dict $imgs.podsMonitor -}}
{{/*
  Per-image pin signal (means "skip auto-refresh for this image"):
  jobs-manager / pods-monitor are pinned when `digest` is set (non-empty) —
  the same signal the deployment uses to switch imagePullPolicy to
  IfNotPresent. The ingestor is no longer refreshed by this CronJob (it is
  spawned by jobs-manager from a floating tag — see the
  image-refresh-cronjob.yaml header and submit_ingestion_run in
  client-runtime), so the CronJob exists only to refresh the two class-1
  images: when BOTH are pinned there is nothing left for it to do.
*/}}
{{- $jmPinned := $jm.digest -}}
{{- $pmPinned := $pm.digest -}}
{{- if not $ir.enabled -}}
{{- else if and $jmPinned $pmPinned -}}
{{- else -}}
true
{{- end -}}
{{- end }}

{{/*
  StorageClass name: when storageClass.create is true, use a release-unique name
  so each release gets its own StorageClass (avoids Helm ownership conflicts).
  When create is false, use the user-provided storageClass.name for an existing class.
*/}}
{{- define "tracebloc.storageClassName" -}}
{{- if .Values.storageClass.create -}}
{{ .Release.Name }}-storage-class
{{- else -}}
{{ .Values.storageClass.name }}
{{- end -}}
{{- end -}}

{{/* Whether to create registry secret and add imagePullSecrets. Only when dockerRegistry is present and create is true; omit dockerRegistry or set create: false for public images. */}}
{{- define "tracebloc.useImagePullSecrets" -}}
{{- if and .Values.dockerRegistry (default false .Values.dockerRegistry.create) -}}
true
{{- end -}}
{{- end }}

{{/*
Image reference — defaults to docker.io when no registry is provided.
When `digest` (sha256:...) is set, renders registry/repo@digest (immutable pin,
preferred for security). Otherwise falls back to registry/repo:tag, where tag
defaults to "prod" when CLIENT_ENV is omitted or empty.
Usage: {{ include "tracebloc.image" (dict "repository" "tracebloc/jobs-manager" "tag" .Values.env.CLIENT_ENV "digest" .Values.images.jobsManager.digest "registry" "docker.io") }}
*/}}
{{- define "tracebloc.image" -}}
{{- $registry := .registry | default "docker.io" -}}
{{- $digest := .digest | default "" -}}
{{- if $digest -}}
{{ $registry }}/{{ .repository }}@{{ $digest }}
{{- else -}}
{{ $registry }}/{{ .repository }}:{{ .tag | default "prod" }}
{{- end -}}
{{- end }}

{{/*
tracebloc.mirrorPrefix — registry prefix for images whose repository is a
registry-less path (docker.io implicit), e.g. the alpine/* utility-pod images.
When a private mirror is set via global.imageRegistry (#585), returns
"<registry>/" so an air-gapped install re-homes those images onto the mirror;
returns "" when no mirror is set, so default installs render byte-identically.
Nil-guarded for --reset-then-reuse-values upgrades that predate global. Call
with the ROOT context (e.g. `include "tracebloc.mirrorPrefix" $`).
*/}}
{{- define "tracebloc.mirrorPrefix" -}}
{{- with (dig "imageRegistry" "" (.Values.global | default dict)) }}{{ . }}/{{ end -}}
{{- end -}}

{{/*
tracebloc.ingestorDigest — the ONE effective digest for the spawned ingestor
image. Renders the digest to pin to, or nothing at all to float on
`images.ingestor.tag`. Every consumer of the ingestor image must go through
this helper so every consumer of the ingestor image (jobs-manager's spawned
ingestion Jobs, any manual backfill Job) agrees on which image is authoritative.

Precedence (most specific first):
  1. `images.ingestor.digest` non-empty  -> that digest, in ANY environment.
     The long-standing per-edge opt-in pin; unchanged semantics.
  2. otherwise the prod gate: `images.ingestor.prodPin` (default TRUE when the
     key is absent) AND the resolved CLIENT_ENV == "prod"  -> `prodDigest`.
  3. otherwise empty -> float on `tag` with imagePullPolicy=Always.

Why the gate is on CLIENT_ENV (backend#1245): dev and staging installs carry
`env.CLIENT_ENV: dev|stg` in their user-supplied values while the chart defaults
CLIENT_ENV to "prod", so this pins prod and floats non-prod with zero per-edge
action — and because `prodDigest` is a chart DEFAULT, a republished pin reaches
installed edges through `helm upgrade --reset-then-reuse-values` (the fleet
auto-upgrade path), which an install-time `-f` overlay never could.

`prodPin` defaults to TRUE when the key is absent so a `--reuse-values` upgrade
from a release predating the key still pins prod, rather than silently
defeating the pin. Every read is nil-guarded for the same reason.

Usage: {{ include "tracebloc.ingestorDigest" . }}
*/}}
{{/*
  Resolved CLIENT_ENV, with the documented aliases normalized to the
  canonical dev|stg|prod keys.

  ONE definition on purpose. Bugbot caught the first cut normalizing inside
  tracebloc.ingestorTag only, so CLIENT_ENV=production selected the prod
  float tag while tracebloc.ingestorDigest still compared the RAW value to
  "prod" and returned nothing -- silently dropping the reproducibility pin
  (backend#1028/#1245) on an edge that looked correctly configured. Any future
  consumer of CLIENT_ENV must go through here rather than re-deriving it, the
  same reason ENV_ALIASES lives once in client-runtime proxy_config.
*/}}
{{- define "tracebloc.clientEnv" -}}
{{- $raw := (default dict .Values.env).CLIENT_ENV | default "prod" -}}
{{- $aliases := dict "development" "dev" "staging" "stg" "production" "prod" -}}
{{- if hasKey $aliases $raw -}}
{{- get $aliases $raw -}}
{{- else -}}
{{- $raw -}}
{{- end -}}
{{- end }}

{{/*
  Effective floating tag for spawned ingestion Jobs (backend#1360).

  Precedence, mirroring tracebloc.ingestorDigest:
    1. `images.ingestor.tag`          explicit override, any environment
    2. `images.ingestor.channelTags[CLIENT_ENV]`   per-environment channel
    3. "0.7"                          last-resort literal, so a release that
                                      predates these keys still renders under
                                      `--reuse-values`

  Only consulted when no digest applies: jobs-manager builds `repo@digest`
  when tracebloc.ingestorDigest is non-empty, and `repo:tag` otherwise
  (client-runtime submit_ingestion_run._build_image_reference).

  dev/stg resolve to the UNSIGNED internal channels. Prod is a semver float,
  not a `:prod` tag — none is published.
*/}}
{{- define "tracebloc.ingestorTag" -}}
{{- $ing := default dict .Values.images.ingestor -}}
{{- $explicit := $ing.tag | default "" -}}
{{- if $explicit -}}
{{- $explicit -}}
{{- else -}}
{{- $clientEnv := include "tracebloc.clientEnv" . -}}
{{- $channels := default dict $ing.channelTags -}}
{{- $channel := get $channels $clientEnv | default "" -}}
{{- if $channel -}}
{{- $channel -}}
{{- else -}}
{{- "0.7" -}}
{{- end -}}
{{- end -}}
{{- end }}

{{- define "tracebloc.ingestorDigest" -}}
{{- $ing := default dict .Values.images.ingestor -}}
{{- $explicit := $ing.digest | default "" -}}
{{- if $explicit -}}
{{- $explicit -}}
{{- else -}}
{{- $prodPin := true -}}
{{- if hasKey $ing "prodPin" -}}
{{- $prodPin = $ing.prodPin -}}
{{- end -}}
{{- $clientEnv := include "tracebloc.clientEnv" . -}}
{{- if and $prodPin (eq $clientEnv "prod") -}}
{{- $ing.prodDigest | default "" -}}
{{- end -}}
{{- end -}}
{{- end }}

{{/*
tracebloc.proxyEnv — corporate-proxy env for egress-needing workloads.
Derives HTTP(S)_PROXY + an auto-augmented NO_PROXY from .Values.env.HTTP_PROXY_*
so workload pods can reach the backend / registries through a corporate proxy.
Renders nothing when HTTP_PROXY_HOST is unset (non-proxy installs unchanged).
NO_PROXY always carries the cluster-internal ranges so in-cluster + MySQL
traffic never traverses the proxy (mirrors scripts/lib/cluster.sh defaults).
Usage inside a container's env: list:
  {{- include "tracebloc.proxyEnv" . | nindent 8 }}
*/}}
{{- define "tracebloc.proxyEnv" -}}
{{- if .Values.env.HTTP_PROXY_HOST }}
{{- $host := .Values.env.HTTP_PROXY_HOST -}}
{{- $port := .Values.env.HTTP_PROXY_PORT | default "" -}}
{{- $user := .Values.env.HTTP_PROXY_USERNAME | default "" -}}
{{- $pass := .Values.env.HTTP_PROXY_PASSWORD | default "" -}}
{{- $hostport := $host -}}
{{- if $port }}{{- $hostport = printf "%s:%v" $host $port -}}{{- end -}}
{{- $cred := "" -}}
{{- if $user }}{{- $cred = printf "%s:%s@" $user $pass -}}{{- end -}}
{{- $url := printf "http://%s%s" $cred $hostport -}}
{{- $noProxy := "localhost,127.0.0.1,0.0.0.0,169.254.169.254,10.0.0.0/8,172.16.0.0/12,192.168.0.0/16,.svc,.svc.cluster.local,.cluster.local,host.k3d.internal" -}}
{{- with .Values.env.NO_PROXY }}{{- $noProxy = printf "%s,%s" . $noProxy -}}{{- end }}
- name: HTTP_PROXY
  value: {{ $url | quote }}
- name: HTTPS_PROXY
  value: {{ $url | quote }}
- name: http_proxy
  value: {{ $url | quote }}
- name: https_proxy
  value: {{ $url | quote }}
- name: NO_PROXY
  value: {{ $noProxy | quote }}
- name: no_proxy
  value: {{ $noProxy | quote }}
{{- end }}
{{- end -}}
